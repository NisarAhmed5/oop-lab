class Hello {
    public static void main(String[] args) {
        System.out.println("/////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
        System.out.println("  Students Points          **");
        System.out.println("/////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
        System.out.println("     LAB    Bonus   Total");
        System.out.println("     ---    -----   -----");
        System.out.println("     43     7       50");
        System.out.println("     39     10      49");
        System.out.println("     50     8       58");
    }
}

