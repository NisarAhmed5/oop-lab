class Hello {
    public static void main (String[] args){
        String name= "nisar", foreigner = "No";
        int age = 20, ID = 7530291;
        float gpa = 2.5f;
        char gender = 'M', grade = 'A';
        System.out.println("Student Name: " + name );
        System.out.println("Student Age: " + age );
        System.out.println("Student Gender: " + gender );
        System.out.println("Student ID: " + ID );
        System.out.println("Foreigner: " + foreigner );
        System.out.println("Student GPA: " + gpa );
        System.out.println("Student Grade: " + grade );
    
    }
}
