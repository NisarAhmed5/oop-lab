class Hello {
    public static void main(String[] args){
        double dollar = 3, pkr = dollar * 278.97 ;
        System.out.println("Enter the value in Dollars: " + dollar );
        System.out.println("Value in Rupees: " + pkr );
 
   }
}
