package Task2;

public class Main {

    public static void main(String[] args) {
        GraduateStudent s1 = new GraduateStudent("Nisar Ahmd", 20, 0005, "XYZ");

        s1.displayInfo();

    }

}
