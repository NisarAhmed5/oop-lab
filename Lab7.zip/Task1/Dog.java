
package Task1;

public class Dog extends Animal {

    void makeSound() {
        System.out.println("Bark Bark...");
    }
}
