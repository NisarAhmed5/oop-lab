
package Task1;

public class Animal {

    String name;
    int age;

    void makeSound() {
        System.out.println("Animal Sound...");
    }
}
