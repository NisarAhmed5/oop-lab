package Task4;

public class Main {

    public static void main(String[] args) {

        Shape shape;

        shape = new Circle();
        shape.Draw(); 

        shape = new Rectangle();
        shape.Draw();

    }

}
