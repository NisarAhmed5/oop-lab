package Task4;

public class Circle extends Shape {

    void Draw() {
        System.out.println("Drawing a cicle");
    }

}
