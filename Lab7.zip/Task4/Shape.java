package Task4;

public class Shape {

    void Draw() {
        System.out.println("Drawing a shape...");
    }

}
