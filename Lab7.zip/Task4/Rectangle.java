package Task4;

public class Rectangle extends Circle {

    void Draw() {
        System.out.println("Drawing a Rectangle");
    }

}
